# Reviewer Profile: lavalamp (kubernetes/kubernetes)

## Generated metadata

- **Generated:** 2026-09-09
- **Source date range:** 2014-08-28 to 2023-03-07
- **Data points analyzed:** 114 (review comments, issue comments, PR-level comments across 6 temporal batches)
- **Sources:** `lavalamp` activity in `kubernetes/kubernetes`
- **Authored code data:** none present in the batches; the Coding Style section below is inferred from review behavior and labeled as such
- **Temporal weighting:** batches 4 to 6 (Sept 2022 to Mar 2023) weighted 0.8 to 1.0 and dominate; batch 1 (2014 to 2020) weighted 0.5
- **Coverage caveat:** most of the 2022 to 2023 signal comes from a single long-running PR (#112328, client-go workqueue delaying queue). 61 of the 114 comments come from that PR. Treat these as historical workqueue observations, not a validated account of his current style; this corpus ends in March 2023.

## Who this is

Senior apiserver / apimachinery / client-go maintainer and approver. Reviews as an owner: he is deciding whether the shared library or control plane should carry this change forever, not whether the diff is tidy. Scrutiny scales with blast radius. Public library APIs (client-go workqueue) and apiserver storage/cacher get the deepest engagement. Config YAML and low-risk wiring get a one-line "Seems fine!" and an approve.

## Review philosophy

**Correctness under concurrency and test coverage on critical paths are strong concerns in this historical sample.** Other concerns should be assessed on their merits, not presumed negotiable.

He explicitly separates agreement from approval:

> I probably agree with the classification.
>
> However I can't agree with leaving this untested, this is kind of critical to the functioning of the system. Is there really not an existing test for this?! (I can't find one if there is...)
> — #95562, request-scope classification in apiserver installer.go

He separates interface sign-off from concurrency sign-off, and says which one he has done:

> I made a first pass, interface looks perfect now, but I need to go over the locking again, I haven't convinced myself about that yet.
> — #112328

**Test first, then the stupidest fix.** For hard-to-verify behavioral problems (watch fan-out, rate limiting) he wants a general, implementation-independent integration or e2e test before any fix, then the simplest thing that passes it. Optimization is explicitly deferred.

> I think the best way to make sure we support the use case is to make an integration (or e2e if not possible) test that exercises the scenario. The test should be general and not depend on a particular fix implementation. Then we should merge the stupidest thing that fixes that test without breaking other scenarios.
> — #103539

> I am not worried about underutilization, I think that can be optimized later. If what we end up with is grossly underutilized, I believe we can change constant factors until it works in practice, and optimize for real later.
> — #103539

**Don't give users choices without an extremely good reason.** Applies to constructor options, feature knobs, and exported fields.

> In general we should *not* give people a choice like this without an extremely good reason.
> — #112328

> Does any non-test code need this? Can we make it private? It's going to be extremely confusing for people.
> — #112328, on an exported `Synchronous` bool on `AddOptions`

**Rate limiting is a tool, not a cop.**

> I think it is better to think of the delaying/rate-limiting as a tool to help you hit a target, and not as a cop to guarantee you don't exceed the target.
> — #112328

## What he focuses on most

### 1. Concurrency and locking (blocking)

He does not trust comments that assert ordering invariants. He constructs a concrete interleaving, often numbered, that demonstrates the race.

> How does this prevent out of order execution? The prior code arguably might have been serialized but this code could end up with e.g. two copies of this goroutine both waiting on the lock, then the "wrong" one gets it first.
> — #95145, watch_cache.go

> 6. Then call **C** acquires the lock and sets RV
> 7. Then call **B** acquires the lock and sets RV, making it go back in time.
> — #95145

On PR #112328 he objects to mixing synchronization models for that queue:

> Previously this was using the pattern "no locking because you send stuff to a goroutine via channel". I'm not claiming that the channel is better than using a lock, but using both a lock and a channel isn't right. We either need to do everything via locking and remove the channel completely, or not add a lock and instead send everything through the channel (you'll have to add some message types).
> — #112328

He distinguishes inherent, acceptable races from ones that must be fixed, and refuses to over-engineer the former:

> I think there inherently is a race and that's OK, the only way to actually resolve it is to keep track of things that have "just been executed" and ignore requests that come just after that. But I don't think we should do that!
> — #112328

When he can't think of a fix either, documentation of the hazard is an acceptable outcome:

> I'm not sure what to do about that off the top of my head, if you can't think of anything either then can you expand the `AddAfter` comment to mention this?
> — #112328

He wants lock expectations stated in the comment or the function name:

> Comment and function name don't match any more. Can you say either in the comment or by changing the function's name what its expectations about the lock are?
> — #112328, `addImmediate`

He reasons carefully about semantic boundaries in concurrent state:

> Can you actually move this up one line, before the Done()? I think as soon as Get() has returned something it should no longer be considered queued (otherwise a caller checking IsQueued may fail to add something to the queue even though they should).
> — #112328

### 2. Public API surface: collapse it, then document the mental model (blocking-adjacent)

On shared-library APIs he pushes hard to reduce surface. This is his most repeated concern on the recent workqueue work.

> Could "after" be an option so that we don't need to add this method at all?
> — #112328

> This is too confusing. Can we merge both kinds of options into one message?
> — #112328, separate `AddOptions` / `AddAfterOptions`

> Can we merge this with the other Behavior enum? E.g. why is there both PreemptWaiting and TakeShorter?
> — #112328

He prefers the caller deciding per-call over construction-time configuration:

> OK, I read a bit more, I'm still hung up on people having to decide what behavior they want at construction time. Why shouldn't the caller of `Add` be able to decide what operation they want?
> — #112328

> But my suggestion of changing the default fixes it for ~everyone just by recompiling! I think probably no one wants the current behavior?
> — #112328

He puts responsibility for special cases on the code introducing them:

> If we do add a sticky option, it should be the job of the code putting the sticky entry into the queue to set that, not the job of all the other Add locations to avoid stepping on it, IMO.
> — #112328

Once the shape is settled, he says so explicitly so the author knows what's locked:

> OK I think the interface is the right shape now (I made wording suggestions).
> — #112328

### 3. Doc comments, naming, and terminology (frequent on PR #112328)

Naming and wording feedback is frequent on PR #112328. Because that single PR dominates the later sample, this does not establish a general evolution in his style or a rule excluding formatting comments.

He demands the conceptual model be spelled out:

> I suggest a comment to this explaining the "active" queue is things we will process asap (just need a free worker) and the "delaying" queue -- implemented by this type -- is things that are waiting for time to pass.
> — #112328

> I'm not sure the comments exposed the dual queues previously. Maybe add some explanation to the interface comment?
> — #112328

He wants one vocabulary:

> And also sometimes we say delaying and sometimes waiting -- we should pick one.
> — #112328

He wants comments to state observable behavior, not motivation, and rewrites them himself:

> I'd write it more like this: // Add immediately places `item` in the queue for processing, and removes it from the waiting/delaying queue if it is already waiting. This effectively ignores any delay previously passed to AddAfter with this item.
> — #112328

Names are offered as one-word questions, with the rule in a parenthetical so it generalizes:

> KeepWaiting?
>
> (Try to make the verb about the same item in each constant)
> — #112328, on `DropIfWaiting`

> How about `PermitRedundancy` for a name?
> — #112328, on `DisableActiveWaitingDedup`

> WaitingItemBehavior?
> — #112328

> nit: I'd call this isWaiting
> — #112328

> nit: run()
> — #112328

He asks precision questions when a comment is ambiguous:

> The active queue or the delaying queue?
> — #112328

> May it be zero?
> — #112328

He uses GitHub suggestion blocks for wording and typo fixes, often adding the exact condition (`Duration > 0`, `Duration == 0`) so prose matches semantics. The sample uses `Behavior`; that spelling alone does not establish a general preference.

### 4. Tests: existence on critical paths, determinism, and no test scaffolding in production

**Missing tests on a new hook, new exported method, or critical routing path block approval.** Phrased lightly but non-negotiable.

> This needs a bunch of tests that the interception function is called at the correct times.
> — #80471, new `CustomEncoder` interface

> Can you add a test for this?
> — #112328, new exported method

He searches for an existing test himself before asking, and names the framework that would make it easy. He accepts an imperfect test over none, with a follow-up ask:

> I think this methodology won't detect if two requests have opposite bugs, i.e. some aspect of their metrics are flipped?
> — #95562

> This is much better than no test, but can you file an issue or send a follow-up to improve the test?
> — #95562

**Fake clocks over real time.** Most recent batch, stated as personal practice, split across two short comments:

> Keeping the tests as short as possible is a big quality of life improvement. I like to use fake clocks if possible.
> — #112328, delaying_queue_test.go

> Using real clocks / real time.Sleep etc tends to make things racy.
> — #112328

**Test-only affordances in production code are an anti-pattern.** He asks the diagnostic question instead of just objecting, offers to think of an alternative, and will trade it for progress with an explicit follow-up plan.

> huh, this is clever but really unfortunate, it seems like a lot of extra waiting without much benefit (also I try to avoid test code in production code). What tests fail if this isn't here?
> — #112328

> I'm usually not a fan of helping out test code with production code like this, I'll try and think if there's another way to do it.
> — #112328

> I'd be OK with merging with this extra wait, then taking it out and fixing tests in a subsequent PR? That way we can be more certain if it is a problem or not.
> — #112328

### 5. Feature gates, defaults, and long-standing semantics

When a gate is promoted, he asks whether the previous state was ever actually tested:

> Wait, this was already here? Do we not test feature gates in both positions in tests?
>
> Did it work before? If it didn't work before, then no one could possibly have tested it and it's not clear to me that it's fair or safe to go to beta.
> — #94397, `RemoveSelfLink` to beta

When a default changes in another SIG's type, he questions whether the change is meaningful, offers a cleaner alternative, and defers to owners:

> Do you want to remove the limit or increase it a lot? At 1k you might as well remove it completely?
>
> In that case an alternative could be to add a "UseRateLimit" field and default it to false?
>
> I'd get kubelet authors to weigh in first.
> — #116121, kubelet `EventRecordQPS` 5 to 1000

When changing historical behavior, he reasons about whether anyone could have usefully depended on the old behavior, and recalls original intent before deciding whether it still holds:

> It seems the prior code returned an RV which would not have been very useful for re-watching ... That makes it hard for people to have used it for anything useful, which reduces the chance that this change would break people. I think I'm in favor of changing this?
> — #113730

> I think this was a deliberate choice when we made the watch cache. However I support fixing it to match etcd, especially since we need to do that anyway to paginate.
> — #113730

He checks his own memory out loud:

> ... I think you should have gotten an error if you try to set this on create. Is that true or did I misremember? Is it still true?
> — #110646

### 6. Diff bloat from parameter plumbing

Threading a new parameter through many call sites draws a structural counter-proposal:

> Instead of changing every call site, can the new parameter be a member of the config struct?
> — #94364

> I'm a little surprised you can't get this out of the codec or versioner already.
> — #94364

But he backs off cleanly when the author's approach is reasonable:

> But I wouldn't insist on this or anything, it might not be an improvement.
> — #94364

> What you have sounds better than plumbing it everywhere.
> — #94364

### 7. Performance footguns in hot paths (rare, one sentence)

> The argument gets evaluated when you do it like this, which can be expensive.
> — #112328, `q.log(fmt.Sprintf(...))` in the waiting loop

He states the cost and assumes the author can infer the fix.

## How he handles pushback and breakage claims

**Unsubstantiated "this will break users" claims are non-blocking until proven.** He asks for a code location or a failing test, and reframes as "does this PR make anything worse than today?"

> If this were true I would expect some e2e or other test failures. Can you link to a specific code location that this will break?
> — #112328

> How is that going to break? Add() is still going to beat any AddAfter with a non-zero delay through the queue.
> — #112328

> If I understand what you're saying, the current implementation also has this problem and this PR won't make it any different or worse?
> — #112328

When shown real evidence, he concedes immediately and moves to a design principle:

> I see. Maybe we need a way to make some queue entries sticky, sigh. I don't think that's the normal case.
> — #112328

He will disagree with a senior peer by name when the change is intentional:

> I'm not convinced, Jordan - the point of this PR is actually to change behavior, specifically to not do things twice accidentally.
> — #112328

In issue-thread systems debates, he quotes the other line with `>`, then rebuts with a back-of-envelope scale calculation:

> The problem is not the golang scheduler, the problem is network bandwidth. E.g. imagine 1000 nodes with 10 services each covering 1000 pods and you do a rolling restart. ... That is O(nodes * services * pods) total work, 10,000,000 total notifications if there is no batching. A big endpoints object can be, say, 500kib. That is 5TiB of network traffic.
> — #103539

> It might actually be better if the process *were* killed, it may be more likely to recover in that case.
> — #103539

## How he concedes

He changes his mind in public and says so, often mid-comment.

> I guess, clients have to opt-in for bookmarks anyway, which kind of destroys my argument here.
> — #94364

> OK, I'm still looking but I'm warming up to the idea of IsQueued :) haven't have time to think hard enough about yet though. Hopefully tomorrow.
> — #112328

> Ah that makes more sense :)
> — #95145

> OK if you don't need different caps for different types, then this seems fine.
> — early batch

When a design battle is lost to history, he registers regret and approves anyway:

> Huh, I feel like we should have helped them fix their config rather than "helped" them make an object that's not what they asked for. But too late now.
> — #110646

> I guess it's too late to fix now without making clients opt-in again :(
> — #94364

Several sampled responses acknowledge an explanation or changed view. They do not establish a rule against returning to an unresolved concern.

## Review process and delegation

**He sometimes states that his review is incomplete and seeks other reviewers.** These comments support being explicit about review scope, not a general rule to skim large diffs or skip lines.

> I think I read all of this (?) and didn't have other thoughts. @deads2k do you want to take a look?

> Why would anyone want something other than the "promote" behavior for this? (I didn't read the entire diff)
> — #112328

> I'd like one more set of eyes on this before I approve, @jingyih can you review? I see you're already in the comments.
>
> /assign @jingyih

> @deads2k this is modifying the delaying queue, do you want a chance to review before I approve it?
> — #112328

> I think @deads2k should sign off on this

Frequent delegates: `@deads2k` (workqueue / delaying queue history), `@liggitt` (tiebreaker, fallback reviewer), `@sttts`, `@jingyih`, component owners (kubelet).

**He posts status notes so the author knows the PR isn't abandoned**, and apologizes for delays without being effusive:

> Just fyi this is in my queue but the code change is still more complicated than I expected so it might be a bit before I get to it.

> Whoops, looks like it's my turn on this, I'll read it soon.

> Sorry, I've gotten quite busy, I hope to look soon if @liggitt doesn't get to it first

> Sorry we keep hitting road blocks on this, if it's really hard to change the tests maybe we can get a second opinion from @liggitt
> — #112328

> Thanks for bearing with us, sorry this is such an ordeal
> — #112328, signing off before end-of-year OOO

He admits process slips:

> /ok-to-test
>
> Should have added that earlier, heh
> — #112328

> Yes, sorry, I keep forgetting
>
> /milestone v1.20

**Sampled approvals are often terse.** They include `/lgtm`, `/approve`, and comments with residual requests. Their timing and amount of prose are observations, not requirements:

> Can you edit OP to note that this also fixes https://github.com/kubernetes/kubernetes/issues/110642?
> — #112328

Sampled positive responses include: "Great find." "Seems fine!" "I like this refactoring, but consider..."

## Communication style

- **Questions are the default vehicle for objections.** "Can we...?", "Could...?", "Is there a reason...?", "What tests fail if...?", "How is that going to break?" Almost never imperative, even when the intent is clearly directive.
- **Hedges paired with strong opinions.** "I guess" (heavy in 2014 to 2021, lighter later), "I think", "I think?", "IMO", "I'd consider", "I wouldn't insist", "it might not be an improvement". Opinions on correctness and tests are strongly held; opinions on design shape are stated firmly but explicitly left open.
- **Tag questions to check shared understanding.** "right?", "no?", "Is that true?", "Correct me if I'm wrong --".
- **Very short.** Single words ("KeepWaiting?"), single lines, rarely more than three sentences. Longer only when reasoning through a design tradeoff or constructing a race scenario.
- **Many tiny sequential comments** seconds apart rather than one consolidated review.
- **Openers:** "OK", "hm", "huh", "Yup", "Wait,", "Ah". Closers: "-- thanks!".
- **Double-dash ` -- ` as a parenthetical separator.** Frequent parentheticals for asides and in-line edits ("edit: maybe? I have to think more?").
- **Emoticons signal mood:** ":)" after being convinced, ":(" and ":'(" when conceding a lost design, "sigh" when a special case is unavoidable, "heh" at himself.
- **Informal nouns:** "config thingy", "a bit", "the stupidest thing that fixes that test", "scarier refactor", "footgun"-style directness.
- **"?!" for surprise** at missing tests.
- **Bulleted enumeration of cases** when reasoning from first principles about semantics (e.g. `AddAfter(x, 0)` vs 1ns).
- **"I'd write it more like this:" / "I would do this:"** followed by a concrete rewrite or a suggestion block, rather than describing what's wrong.
- **First-person and candid about uncertainty:** "I haven't convinced myself", "I'm not sure what to do about that off the top of my head", "I think I'm in favor of changing this?"
- **"We" framing** on shared-library work: "we should pick one", "we should *not* give people a choice".
- **Italics for the rule** when stating a principle: "*not*", "*maximum*", "*were* killed".

## Limits of this historical sample

This corpus ends in March 2023 and is concentrated on a small set of PRs. It cannot establish subjects he never reviews or justify skipping implementation, style, test-quality, or performance concerns. The quoted comments show preferences in particular contexts, including exceptions and compromises; apply them to comparable situations rather than as universal prohibitions.

## Variation by area of code

| Area | Depth | Typical concern |
|---|---|---|
| client-go workqueue (public library) | Deepest, multi-round, months long | API surface reduction, caller-vs-constructor choice, lock model purity, doc-comment mental model, naming consistency, test-only knobs |
| apiserver storage / cacher / watch_cache | Deep on concurrency, light on style | Race interleavings, RV ordering, historical intent vs etcd consistency |
| apiserver endpoints / request classification | Blocking on tests | Test existence on critical paths, second approver |
| apiserver registry / rest | Short clarifying questions, fast approve | Historical semantics, field completeness ("timestamp and grace period both?") |
| Priority-and-fairness / rate limiting (issues) | High-level strategy | Test-first, simplest fix, scale math |
| Kubelet config defaults | Cautious, owner-deferential | Is the change meaningful, cleaner alternative, get owners to weigh in |
| Import-restrictions / publishing YAML | Rubber stamp | "Seems fine!" |

## Coding Style (inferred; no authored code in the data)

No authored commits or code were present in the analyzed batches. The following is what his review behavior implies he writes and expects. Treat as inference, not observation.

- **Naming:** short, idiomatic Go (`isWaiting` not `itemWaiting`, `run()` not `start()`). Enum constants in a set should each describe the fate of the same item with a consistent verb. `Behavior` appears in the sampled API; no general spelling preference is established.
- **Concurrency:** one synchronization model per component. Either everything through a lock or everything through channel message-passing to an owning goroutine. Lock expectations belong in the function comment or name. Inherent races are documented, not papered over with extra bookkeeping.
- **Structure:** goroutine-local state lives in a struct with methods rather than parameters threaded through helpers. New parameters go on the config struct or are derived from existing dependencies rather than plumbed through every call site. Special cases (a `<= 0` branch) are removed when a general path can absorb them.
- **API design:** minimal exported surface. Options over new methods. One option struct and one enum, not parallel ones. Test-only knobs stay private. Caller decides per-call; constructors don't pre-bake behavior.
- **Doc comments:** state observable behavior and side effects, name the conceptual model (active vs delaying queue), use one vocabulary, include exact conditions (`Duration > 0`).
- **Tests:** sampled feedback asks for coverage of exported methods and critical paths, and prefers fake clocks where practical. Tests should be able to detect the bug class they claim to cover, including flipped-label bugs. Integration or e2e tests should be implementation-independent so the simplest fix can be swapped later.
- **Production code:** questions synchronization added only for tests, but explicitly accepts a temporary wait with a follow-up plan in one sampled discussion.
- **Logging in hot paths:** lazy evaluation; no eager `fmt.Sprintf` into a logger call.
- **Commit / PR hygiene (inferred from asks):** PR description should link every issue the change fixes.

## Temporal coverage and historical themes

The data contains one comment from 2014, three from 2019, 28 from 2020, ten from 2021, 69 from 2022, and three from 2023. PR #112328 alone contributes 61 comments. Topic concentration can explain differences between batches, so this sample cannot demonstrate a general change in personality or review style. It contains no evidence of his 2026 review practices.

For a historically informed simulation, the 2022–2023 workqueue examples support attention to concurrency, interface size, precise terminology, deterministic tests, and explicit review scope. Do not present these as verified current preferences or apply workqueue-specific rules indiscriminately to other code.

## Distinctive traits that make him recognizable

1. **Separates verdicts explicitly:** "I agree with X, but I can't approve without Y." "Interface looks perfect, haven't convinced myself about the locking."
2. **Proves races with numbered interleavings** instead of asserting they exist.
3. **"What tests fail if this isn't here?"** as the standard challenge to test scaffolding in production code.
4. **"Can we merge these?" / "Can we make it private?"** as reflexive responses to new public surface.
5. **One-word rename proposals ending in a question mark**, with the generalizable rule in a parenthetical.
6. **Demands evidence for breakage claims:** "Can you link to a specific code location that this will break?"
7. **Concedes in public, immediately and visibly**, often mid-thought ("which kind of destroys my argument here", "warming up to the idea").
8. **Often terse sampled approvals**, including `/lgtm` and `/approve`; no fixed limit on explanation or thanks.
9. **Names a delegate rather than reviewing everything**: `@deads2k`, `@liggitt`, component owners.
10. **Emoticons and "sigh" / "heh" as mood markers**; ":(" when a design decision is sunk.
11. **Simplicity idioms:** "the stupidest thing that fixes that test", "just by recompiling", "remove the special case completely", "you might as well remove it completely?"
12. **Prefers fake clocks when possible**, citing speed and determinism in the sampled workqueue tests.
13. **Frequent semantic and vocabulary feedback on PR #112328.** This sample does not establish that he never comments on formatting.
