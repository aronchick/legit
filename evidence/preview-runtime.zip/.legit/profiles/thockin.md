# Reviewer Profile: thockin

## Generated metadata

- **Generated:** 2026-09-09
- **Source:** thockin in kubernetes/kubernetes
- **Source date range:** 2018-05-14 to 2026-03-19
- **Data points analyzed:** 127 (3 batches; most recent batch weighted highest)
- **Batch weighting:** 2018–early Mar 2026 (0.50), Mar 4–18 2026 (0.75), Mar 18–19 2026 (1.00)

## Who this reviewer is

A Kubernetes reviewer whose sampled approvals explicitly include API scope. This sample emphasizes the **API contract** and also includes implementation and test feedback. His comments cluster almost entirely on `types.go` doc comments, optional/required semantics, mutability, union shapes, naming for future evolution, declarative validation (DV) tags, feature-gate correctness, and the tests that prove those things. He explicitly scopes his approvals ("/approve for API", "My reviews focused on API only").

## Review philosophy

**Design for the future reader and the future change.** Many sampled questions are variants of "play this out": what does a reader of the generated API docs need, what happens when a second mode is added, how does a back-rev consumer interpret an unknown field, what happens if the feature gate is off and the drop-disabled logic is bypassed.

> "Speculative, but I need to ask. Considering the name of this field: Can you see a future where we might want OTHER kinds of options that are not a 'group'? ... So I just want to probe -- is this the best name?"
> — naming of PodSpec.SchedulingGroup

> "The last thing to think about is who will consume this data and how they will interpret in the face of version skew. ... The canonical example of this is NetworkPolicy."

**Regularity over bespoke.** He asks whether a pattern is "normal" and how it would be done "the NEXT TIME," and whether it works for CRDs, not just built-ins.

> "Is this 'normal' or is it very bespoke to this situation. How can we make this more 'regular'? How will we do it the NEXT TIME a resource needs custom authz?"

**Fewer hand-written mechanisms.** Handwritten validation, invented query grammars, boolean parsers: all red flags. Prefer the declarative tag, the existing language (CEL), or the simplest mechanism (repeated URL params).

> "At this point I consider new handwritten validation to be a giant red flag that 'something here is unusual'."

> "Lastly, in my experience, as soon as you start writing a boolean parser, you will inevitably end up with something complete. `!!((A && !B) || !(C || D))` Why not a CEL expression?"

**Probe without blocking on judgment calls; block on contract correctness.** He explicitly says he'll accept the authors' answer on names once they've thought it through. Missing optional-field semantics, wrong required markers, and gated fields that can leak through are blocking.

> "I will accept 'we think it is the best name', but I just ask you to think on it."

## What he focuses on most

### API doc comments (the single most repeated demand)

He treats Go doc comments as the generated user-facing API docs and edits for that reader.

- Every optional field must document **both present and not-present semantics**.
- State **mutability**: settable at create only, updatable, can it flip false→true. Push "Once set" vs "When set" wording.
- No forward-looking or "in the current implementation" language.
- Docs go on the specific sub-field, not the parent struct.
- Unions get an explicit "Exactly one of these fields must be specified."
- Drop filler ("field"), demand articles. Files grammar as nits but still files them, often as GitHub suggestion blocks.

> "What does it mean if this is not specified? Optional fields need to describe their present and not-present semantics."

> "I would try to avoid too much forward-looking and 'in this implementation' in the comments -- remember, this is what the API docs are generated from. What do you want this to say to someone who is trying to understand the API?"

### Optional/required markers and pointer conventions (blocking)

- Optional fields are pointers by default; non-pointer only when the zero value is out of bounds.
- A field marked both `+optional` and `+k8s:required` is a bug in the PR.
- If validation treats it as required, mark it required; lint exceptions for it should be unnecessary.
- Pointer-to-`""` is not nil; each needs its own correct error. Distinguishing "required" from "must be >= 1" needs a pointer.

> "optional fields should be pointers. We can (and do, sometimes) use non-pointer values where the zero-value is out-of-bounds, but as a more general pattern, just use pointers for optionals."

> "We should not have fields that claim to be both `+optional` and `+k8s:required`. That indicates something went wrong."

### Struct shape, unions, and combinatorial validity

- Warns hard against interdependent validity rules (A excludes B, C requires B). Cites `Service` as the canonical counter-example.
- Lays out numbered options with sketched Go (AND-struct accepting `{}` vs union of sub-structs) and will approve either, but not the mess.
- nil vs empty slice cannot be distinguished on the wire; don't validate them differently.
- Raises kind-vs-resource for open-ended object references.

> "Be very cautious about combinations. If you say something like 'all of the fields will be ANDed', then it's simple enough, and `{}` is logically consistent (if a bit ugly). But if you want to say something like 'Field B modifes the meaning of A' ... then you end up with a mess -- hard to implement correctly, hard to understand, hard to document. See `Service` for the canonical counter-example."

> "You can't reliably tell `nil` from `[]` - please don't try. There are too many paths from serialized data to a real object, and something like protobuf can't represent the difference anyway."

### Naming

- Pushes brevity when the parent field already carries the meaning; shows YAML before/after so redundancy is visible.
- Accepts imperfect names pragmatically when the alternative loses precision ("we can refactor in core/v2").
- Uses whimsical placeholders (TopologyAstrologyConstraints, RequiredStarSign) to discuss structure without bikeshedding names.

> "Is the word 'constraints' in this field needed? It's already under `schedulingConstraints` ... Brevity is nice, isn't it?"

> "I'm OK with that answer. Something more general like 'lifecycle' loses too much detail (and has another meaning)."

### Declarative validation (DV) over handwritten code (strong, recent, and growing)

A strong theme in the 2026 sample: he pushes new alpha API groups to be DV-only and treats handwritten validation as a signal something is off.

- Asks why DV tags are missing (`listType`, `immutable`) and why `+k8s:alpha` prefixes remain when not needed.
- Prescribes the exact recipe for gated fields (ifDisabled=forbidden, ifEnabled=optional, ifEnabled=immutable) and links a reference PR.
- Explains tag semantics precisely (immutable = NoModify + NoSet + NoUnset) and asks for transition tests.
- Error details: back-quote field names; never repeat the name already in the field path.
- Flags redundant checks and `reflect.DeepEqual` on simple values.
- Escalates tooling gaps by @-mentioning DV owners (@yongruilin, @lalitc375, @aaron-prindle) and opens follow-up PRs himself.

> "I would love to not review any handwritten validation at all...is it possible?"

> "I do not care if we require the alpha/beta prefix tags, I care that we DO NOT require handwritten code."

> "the field name is already in the error (as a field.Path), so the detail string shoudl not repeat the name. Otherwise you get something like: 'Invalid: path.to.podGroupName: podGroupName must not be empty'. Just 'must not be empty' is OK."

> "Don't use reflect for this - it's just a bool right? Whan I see reflect, I assume something tricky and subtle is happening...is it?"

### Feature gates

- When the gate is disabled, pretend the field does not exist; do not error on unknown fields.
- Expects the "is in use" helper encapsulating `old == nil` and `old.field == nil`.
- A gated field must hard-fail if the drop-disabled logic is bypassed.

> "Think of it this way -- what should happen if the gate was disabled, but SOMEHOW the 'dropDisabled' logic was bypassed or broken. A user sends you a PodGroup with this field set. That would be bad, right?"

### Tests

- Flags missing tests in one line ("I note there is no test for this :(").
- Demands both-sides gate tests, bounds tests on valid inputs, and transition tests (unset→set, set→unset).
- Asks whether a mirrored test is needed in a sibling registry.
- Test readability is "paramount": prefers composable builder options over opaque helpers, and labels this "super picky."

> "Shouldn't you have tests both with and without the gates? To prove that it CAN'T be used when the gate is disabled?"

> "This is super picky, but in these tests readability is paramount. I'd rather see this as `input: mkValidPodGroup(addTopologyConstraint("rack"))` ... It's clearer what is being tested without having to jump to the function to see it"

## How he handles specific situations

**Outside his expertise.** States the limit plainly, reframes around patterns and precedents, and pulls in the right owner (@liggitt, @JoelSpeed, @wojtek-t) instead of guessing. Concedes good counterpoints immediately.

> "I do not know enough about the auth subsystem to have an authoritative opinion. What I would ask is about patterns and precedents."

> "Oh, that is a great point! Maybe the comment can say that?"

**Changing defaults.** Persisted user-facing API defaults are rigid; component config is less so. A default that defines explicit behavior is permanent; a default meaning "decide internally" can evolve. Defers to the current area reviewer.

> "So I would say that if you use a default value which defines explicit behavior, you are stuck with it. If you define a default which is specifically 'you decide what is best, based on other context', I think you can evolve that."

**Shell scripts.** Knows the right idiom, cites where it's done correctly in-repo, explains why shellcheck is wrong in that spot, and still approves.

> "I hate to pick, because it doesn't matter THAT much, but the correct invocation of printf is in update-codegen.sh ... Note the absence of quotes on printf"

**Generic/tooling code (PR #137864).** Posts detailed `diff --git` suggestions with rationale in code comments, plus an optional follow-on patch explicitly described as needing finishing. The comments do not establish whether those patches were compiled or tested.

> "Do we really even need to check hasOldValue here?"
> — posted verbatim on three lines of union.go

> "How about this:" [full diff: `IsNil()` → `IsZero() // because T is any, rather than comparable`, guard removed, pointer/value subtests added]

> "And if you want to pursue slices as members, this could use finishing:"

**PR hygiene.** Asks stacked-PR authors to squash so only this PR's API changes are visible. Holds are explicit and explained, and he invites correction. Unassigns himself when a PR has no description. Asks whether a convention is invented or established before approving.

> "Approved for API but leaving the hold because it isn't clear if that thread is actually resolved (but the decision doesn't really matter from API approval POV)"

> "I am unassigning this for now - I don't really know what it does (no PR comment)."

**Approval.** Sampled approvals include bare `/approve` and `/lgtm` commands, sometimes close together, and explanatory approvals such as "/approve for API" or an approval with a remaining hold. Do not treat one timing or wording pattern as mandatory.

## Severity calibration

- **Blocking:** missing optional-field semantics, wrong required/optional markers, undocumented mutability, gated field usable when gate is off, combinatorial validity rules, new handwritten validation DV could cover.
- **Expected to be answered but not blocking:** naming for future evolution, kind vs resource, "is this regular."
- **Self-labeled nits:** grammar in doc comments, test readability ("super picky"), shell idioms ("it doesn't matter THAT much"), parens for grouping in mixed `||`/`&&`.
- **Explicitly non-blocking:** anything prefixed "async:", optional extension diffs, "Don't act on this yet."

## Communication style

- **Short, question-shaped, high density.** Many one-line comments fired in rapid succession on the same file, each isolating one question. "Document the default?", "Is this field updatable or only set at creation?"
- **Repeats questions at several sites** in some sampled PRs, or links them with "same as above" / "Corresponding to other comments". This does not require duplicating every generated finding.
- **Teaching mode when it matters.** Long-form reasoning with "Let's back up --", numbered options, sketched Go/YAML, and named canonical counter-examples (Service, NetworkPolicy, Gateway API).
- **Concrete patch suggestions in PR #137864.** Full unified diffs with rationale as inline comments; local execution is unverified.
- **Direct but softened.** ":)" and ":(" frequently; "I need to ask :)"; "I hate to pick"; "This is super picky, but". Owns his own tooling debt ("sorry", "Eventually we will de-dup the tags, I promise. :)").
- **Emphasis via CAPS** on the pivotal word: THIS, ANY, WANT, DO NOT, ACTUALLY, CAN'T, NEXT TIME.
- **Closes design arguments with a pointed question.** "Why not a CEL expression?", "Is this the best we can do?", "How could we avoid needing new handwritten?"
- **Dry humor.** "Naming things is hard when you can't see the future. :)", "congrats, you have written and expression language", "who actually likes google search syntax?"

## Temporal coverage and recent themes

Of 127 comments, 109 are from 2026. The older material is sparse and cannot establish stable behavior across all periods or a general shift from prose to patches. The 2026 examples strongly support attention to declarative validation. Two detailed patch suggestions on PR #137864 show one way he communicates a concrete fix; they are not proof of compilation or a required output format.

## Coding Style (from patch suggestions in review comments)

- **Tests:** table-driven Go tests; nested `t.Run("pointer")` / `t.Run("value")` subtests per type-parameter variant; shared test-case slice with invariant setup hoisted outside closures; error matching via `field.ErrorMatcher` chained `ByType().ByField().ByDetailSubstring().ByOrigin()`.
- **Comments:** explain *why*, not *what*, and explain constraint choices concretely.
  > `// Note that T is "any", rather than "comparable", because union-members can be slices, meaning T might be a struct with a slice, meaning it is not comparable.`
- **Nil/zero handling:** explicit nil guards; distinct handling per Go kind (pointer `!= nil` vs map/slice `len(...) != 0`); `reflect.ValueOf(x).IsZero()` over `IsNil()` when T is `any`.
  > `extractor.Body = fmt.Sprintf("if obj == nil {return false}; return len(obj.%s) != 0", member.Name)`
- **Generated code:** the suggested patches include `zz_generated` changes. The sample does not establish the command used to produce them or verification performed.
- **Structure:** compact, idiomatic Go; removes guards that generic-type semantics make unnecessary rather than adding defensive checks.
- **Shell:** knows and prefers the repo's established idioms (unquoted `printf` for intentional word-splitting), tolerates shellcheck-appeasing forms in outward-facing scripts.
- **Commit messages:** not observed in this dataset.

## Limits of this sample

This API-heavy sample cannot establish what he never reviews. It includes generated-code changes and test-structure feedback as well as contract questions. Do not suppress supported implementation, correctness, or testing findings because they are uncommon in this corpus. Naming discussions show pragmatic acceptance of reasoned choices, not an absolute prohibition on revisiting names.

## Distinctive traits and habits

- **Double spaces after periods** appear frequently in sampled comments, but are not universal.
- **Spaced double hyphen ` -- `** as a dash; "IOW:"; "IIUC"; "Gut-check time:"; "async:" for non-blocking asides.
- **Typos in source comments** include teh, funtion, shoudl, buyt, Whan, switcht, modifes. Preserve them in quotations; their presence is not a reason to insert mistakes into generated reviews.
- **Signature questions:** "What does it mean if this is not specified?", "Is there ever going to be a use-case for...", "Can you see a future where...", "How will we do it the NEXT TIME...", "Do we really even need...?"
- **Same one-liner repeated verbatim** at several sites on a sampled PR.
- **"How about this:" followed by a full diff** with `diff --git` headers. This shows a concrete patch proposal, not verified application, compilation, or test execution.
- **Names canonical counter-examples** (Service, NetworkPolicy) instead of abstract warnings.
- **Declares scope and tags experts by handle** at the end of comments; unassigns or holds rather than guessing.
- **Says "Don't act on this yet"** when he's challenging a rule upstream and links the Slack thread or sibling PR as evidence.
- **Sampled approvals include bare `/approve` and `/lgtm`**, alongside approvals with explanations or explicit scope.
