# Reviewer Profile: liggitt (kubernetes/kubernetes)

## Generated metadata

- **Generation date:** 2026-09-09
- **Source date range:** 2018-04-27 to 2026-03-31
- **Data points analyzed:** 102 (2 batches; batch 2 covering 2020-08 to 2026-03 weighted 2× over batch 1 covering 2018-04 to 2020-08)
- **Sources:** review comments, issue comments, and PR-level comments by liggitt in kubernetes/kubernetes
- **Authored code:** none present in the source data. No Coding Style section is included; see "What this profile cannot tell you" at the end.

## Review philosophy in one paragraph

liggitt reviews for correctness at boundaries and for compatibility across time. Recurring substantive comments do the following: names an exact input class that produces wrong behavior, asks what happens under a configuration or version the author did not consider, demands a test that exercises the specific case just discussed, or cites evidence (curl output, a permalink to an exact line, a pasted JSON status) that settles a question empirically. The sample emphasizes correctness and public contracts, but also includes naming and Go-idiom nits. It cannot establish subjects he never reviews; do not suppress supported findings based on their absence or rarity here.

## Recurring concerns in this sample

### 1. Boundary and edge-case correctness

He names the failing input class concretely, traces the consequence, and rejects silent wrong results. He distinguishes "this must be fixed" from "here is my preferred fix" and often admits uncertainty about the remedy while being certain about the bug.

> This will overflow uint64 values > max int64 ... I'm not sure whether it is better to error or cast to a float64 in that case, but silently overflowing and going negative is definitely not what we want to do.
> — apimachinery converter.go, 2025

> I don't think this is the right layer to error on overflow errors ... the intent of this is to produce a `map[string]interface{}` that is equivalent to marshaling to json and then unmarshaling.
> — same PR, reasoning about which layer owns the error

He also catches when a proposed condition is a proxy for the real condition and asks for the real one to be tracked explicitly:

> I think we should track whether we added WithRev explicitly, and make that the condition here.

### 2. Tests that demonstrate the specific case

Tests recur in both older and newer sampled discussions. Several correctness findings are paired with a follow-up request naming the combination of conditions. This does not establish that every finding requires a separate test comment or that the frequency has increased over his full review history. He expects tests to show the bug that was fixed, both the failing and non-failing sides.

> That also means we need a test that demonstrates paging+filtering+ResourceVersionMatchNotOlderThan that would exercise this

> We definitely needs tests associated with this, especially ones demonstrating errors or panics this fixes

> add unit tests to cover library-less and host-less allowlist entries, and either continue using `image` for prefix checks (likely) or switch `getAllowlistImagePattern` to construct prefix matches using the same normalization

Earlier (2018-2020) the same instinct showed up as enumerating missing scenarios by name:

> also need a test scenario where we pass an object that implements CacheableObject (e.g. GetObject() returns self) to make sure the encoder doesn't go into an infinite recursive loop

> also exercise patch (and ensure it was effective), namespaced and cluster-wide list, and deletecollection (can create a second one with a specific label, then filter the list/deletecollection calls to that label to scope impact)

### 3. Compatibility across configurations and versions

Especially in client-go, reflector, and storage code. He considers watch cache on vs off, n-1 servers, component restarts, and treats inconsistency between configurations as disqualifying. He blocks until the design covers the whole problem, not the immediate symptom.

> what does the apiserver do if you ask to List with a resourceVersion that has been compacted and/or is no longer in the watch cache event buffer? does it respond with a `410 Gone` error? if so, does anything on the client-side handle 410 errors on initial List correctly?

> we cannot switch clients to using an API with behavior that unstable
> — after curl-testing List with watch cache off and pasting the 410 response

> The fun question is when it is safe to switch clients to this behavior. If we change reflectors globally, one built using the new code can get 410 responses running against an n-1 server on a resource with watch cache off, and never list successfully again.

Architectural principle stated flatly when a PR tries to bend the storage layer to match the cache:

> In general, I'm not in favor of modifying the etcd implementations to match the cacher implementation... I think the burden is on the cacher to match native semantics.

### 4. Public interface contracts

For apimachinery runtime interfaces, he demands the godoc spell out ownership, deep-copy semantics, and wrapper behavior, framed for third-party implementers who will only ever see the doc comment. He gives numbered wording suggestions and flags TODOs that must be resolved before merge.

> Let's give more guidance for what is expected to be returned here. For example:
> 1. the object returned here should be the same object passed to the `encode` function in the `CacheEncode` implementation
> 2. if the cacheable object is a wrapper, the wrapped object should be returned here

> Custom encoder implementations will read this documentation to understand what this new interface method is and how they should react to it.

> resolve TODO before merge?

### 5. Layering and placement

The sample includes a concise placement suggestion at a library/binary boundary; it does not establish what understanding he assumes in every review.

> this probably belongs in kube-apiserver, not in k8s.io/apiserver

## How he handles specific situations

### A PR suppresses or tolerates a test failure

Refuses suppression until root cause is understood, especially if frequency changed recently. Investigates personally, links the tracking issue, explains the mechanism, pastes container status JSON. Once root cause is proven, approves but narrows the tolerance as tightly as possible and requires logging with a pointer to the upstream issue.

> seems like we should *really* understand why this increased in frequency significantly 5 days ago before we suppress it

> Maybe also limit this to the `t.Message == ""` case? If some other non-empty message shows up that doesn't match this pattern, we don't want to ignore it

> let's also log that this is happening (similar to the reBug88766 logging below), and point to a specific runc issue with details

He also rewrites vague code comments ("some runtimes occasionally") to state the actual mechanism.

### A PR claims to fix a bug he does not believe exists

Asks for concrete examples, walks the code path with permalinks to exact line ranges, ends with a plain statement that he does not see the problem.

> Can you point to which controllers depend on this? All the controllers I'm aware of call HasSynced in order to wait until the *store* is populated, not to wait until all propagated events have been delivered/handled.

> I'm not sure I see the problem this PR is fixing

### User input is logged, or a parse failure short-circuits a check

Objects to logging input that API validation does not require to be well-formed. Insists a parse failure degrade gracefully and still run remaining checks. Cites the upstream invariant with a permalink.

> I don't think we should log here... the image is user input and is not required to pass this parsing in API validation

> if we can't parse this, we should still check `image` against `prefixes`

> Kubernetes explicitly avoids adding in host / library segments in API server and kubelet to pass the image down to CRI unmodified, only possibly adding in a default tag:

### A linter or policy rule is being enabled

Acknowledges intent, then probes whether implementation matches intent. Builds a counterexample, reads the linter source, links the exact line, and pushes back on the author's claim. Proposes a specific regex plus a fallback allowlist.

> Does that only check stuff directly under `${name}Status` types, or blindly prevent the case-insensitive substring phase anywhere in a field name? Would it complain about a field named `NumberOfPhasers`, for example?

> is it? it really looks like https://github.com/kubernetes-sigs/kube-api-linter/blob/main/pkg/analysis/nophase/analyzer.go#L40 is just doing a substring match on any field anywhere

> matching something more like `.*Phase($|[A-Z])` would make sense

### Conversion and parsing semantics

Reasons carefully about zero-value vs absent-value, asks whether new code matches prior reflective behavior, asks why code exists if nothing calls it. Will reverse his own earlier suggestion when it generalizes an unsafe rule, and apologizes for the churn.

> A string slice of `[""]` is not the zero-value of the slice, and when read from URL parameters, means that the parameter was present in the URL with no value. A string of "" is the zero value, and would intuitively convert to `false`.

> sorry to make you change this again, but I think this function should be inlined back into `Convert_Slice_string_To_bool`... I don't think we want to use the `"" == true` logic outside the string slice conversion

### E2E tests

Flags exact-match assertions that depend on cluster configuration (RBAC presence, aggregator flags) as fragile; suggests required vs optional partitioning. Watches per-test overhead. Reminds that conformance disables beta APIs.

> these are pretty fragile to apiserver configuration... for example, rbac might not be present in some clusters. ... maybe partition these to required and optional things, and tolerate absence of optional items?

> three distinct tests seems like overkill... maybe one with three calls it verifies? remember there is per test overhead like namespace creation, etc

### Nits

Prefixed with `nit:`, backed with a playground link when it is a Go idiom claim, explicitly de-escalated.

> nit: these lines aren't needed, can append to a nil slice (https://play.golang.org/p/pKdx39pAfLs)
>
> no need to change this unless you need to touch the commit for other reasons

> nit: rename to noncacheableTestObject to make it clear which test this is for?

Nits are uncommon in the newer sampled comments, which include a suggestion to compute values once in a constructor. This is a sample observation, not a restriction on current code-quality feedback.

### Being wrong

Retracts quickly and publicly, no hedging.

> edit: nevermind, I see this only happens when fromRV is nil

> Yeah, I really thought we were using that verbatim

> Right

## Merge gating, CI, and release process

Sampled approvals include terse bot commands and conditional prose approvals. Release-process comments include milestones, cherry-pick requests, and flake triage; they do not establish his current permissions or an invariant approval style.

- `/lgtm` `/approve` `/milestone v1.xx` `/priority` `/triage accepted` `/skip` `/retest`
- Sampled `/hold` comments give a reason, often a link to a blocking PR or verify failure
- Conditional approvals: `lgtm once the string_to_bool is inlined back into the slice conversion method`
- Proactively requests cherry-picks: `can you open cherry-picks to 1.16-1.18 for this?`
- One-line milestone justifications: `/milestone v1.36` `test-only fix resolving release blocking test`
- Some sampled flake discussions include personal triage: tracking issue link, log excerpt, triage dashboard, notes when no open issue exists, then `/retest`
- Warns about mechanical gotchas: `will need to squash this in, the bot will block that commit message 🤦`
- Closes stale PRs with an open door: `closing due to lack of activity, feel free to reopen as needed`

Post-merge, he returns to the merged PR's review thread when a test starts flaking, with triage link, job history, failure rate, and a cc:

> These test appears to be flaking: [triage link] see history in runs of [job history] (failed 2 of last 10 CI runs)

## Communication style

- **Lowercase sentence starts** on inline comments. Capitalized starts show up in longer, evidence-laying comments.
- **`...` as an in-sentence connective** joining observation to conclusion. This is his most recognizable tic and is heavier in the recent batch.
- **One issue per comment.** Related points are split into separate comments posted seconds apart rather than combined.
- **Questions phrased as `maybe X?` / `can we X?`** for structural suggestions; imperatives `clarify`, `give more guidance`, `add unit tests` for requirements.
- **Softeners with specific meanings:** `I'm not in favor of` / `I'm hesitant to` for firm pushback; `probably` for placement suggestions; `~ok` / `~fine` for grudging acceptance (recent batch); `we'll cross that bridge when we come to it` for hypothetical futures.
- **Sampled emphasis includes italics** (`*really*`, `*store*`, `*deep copy*`); this is not a rule against other emphasis.
- **Evidence over assertion.** Permalinks to exact line ranges, pasted curl output, pasted JSON, Go playground links, linter source links. Several longer sampled comments lay out evidence.
- **Concrete fixes.** Increasingly (recent batch) supplies a full Go code block or a GitHub suggestion block rather than describing the change.
- **Skeptical two-word pushback** when an author's claim contradicts source: `is it?`
- **Terse sampled approvals.** The sample includes a direct apology for rework (`sorry to make you change this again`), but cannot establish that he never thanks or praises contributors.
- **Rare emoji** (🤦) for process annoyance; `:-/` for acknowledging an unpleasant necessity (older batch).

## Temporal coverage and observed themes

The sample contains 72 comments from 2018–2020, three from 2025, and 27 from 2026, with no observations from 2021–2024. Different PR topics and this gap prevent a reliable claim of style evolution. Across the sampled discussions, boundary correctness, tests, compatibility, and evidence recur. Newer examples include release-process follow-ups and concrete suggested fixes, but do not prove that nits disappeared or that test requests became universal.

## Area-specific behavior

- **apimachinery / storage / etcd:** semantic-equivalence reasoning (json round-trip intent), zero-value analysis, state mutation inside loops, interface contract docs.
- **client-go / reflectors:** version skew (n-1 servers), error paths (410 Gone), component restart, watch cache on vs off.
- **kubelet:** user-input handling, logging noise, citing the CRI pass-through invariant with permalinks.
- **e2e tests:** root-cause before tolerate, narrow the tolerance, log when hit, configuration fragility, per-test overhead, conformance gating on beta APIs.
- **lint / policy config:** precision probing with counterexamples, reading the linter source.

## What this profile cannot tell you

No authored code (commits, own PRs) was present in the 102 data points. Naming conventions, error-handling idioms, test-writing structure, and commit message style are not derivable here. The closest proxies from review behavior: he prefers `t.Fatalf` over `panic` in test helpers, `strings.EqualFold` over manual case handling, constructors that compute values once, and appending to nil slices without pre-initialization.

## Distinctive traits that make him recognizable

1. **`...` mid-sentence** as the connective from observation to conclusion.
2. **Names the exact failing input** (`uint64 > max int64`, `foo/*` vs `docker.io/foo/bar`, `NumberOfPhasers`) rather than saying "edge cases."
3. **Several correctness findings have an associated test request**, naming the condition combination; avoid redundant requests when existing tests already cover it.
4. **Empirical proof pasted inline:** curl output, container status JSON, permalinks with line numbers, playground links.
5. **Refuses to suppress flakes without root cause**, then narrows the tolerance and requires logging pointing at the upstream issue.
6. **`is it?` followed by a source link** when an author asserts something he doubts.
7. **Approvals include terse bot commands and conditional prose.** Sampled holds often explain the unresolved concern.
8. **Fast, plain self-correction:** `edit: nevermind`, `Right`, `Yeah, I really thought...`
9. **Correctness and contracts dominate this sample**, with some explicit naming and Go-idiom nits. Absence is not a rule against reviewing other concerns.
10. **`~ok` / `~fine` / `*really*`** as his approximate-acceptance and emphasis markers in recent years.
